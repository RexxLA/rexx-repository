var searchData = [
        {
        id: "Properties.cls", type: "Package", name: "Properties.cls", info: null,  href: "Properties.cls.html"
    },
        {
        id: "MultiStageTable", type: "Class", name: "MultiStageTable", info: "Properties.cls", href: "Properties.cls.html#MultiStageTable"
        },
            {
            id: "init", type: "Method", name: "init", info: "Class MultiStageTable", href: "Properties.cls.html#init"
            },
            {
            id: "%5B%5D-1", type: "Method", name: "[]", info: "Class MultiStageTable", href: "Properties.cls.html#%5B%5D-1"
            },
            {
            id: "Compress", type: "Method", name: "Compress", info: "Class MultiStageTable", href: "Properties.cls.html#Compress"
            },
        {
        id: "PersistentStringTable", type: "Class", name: "PersistentStringTable", info: "Properties.cls", href: "Properties.cls.html#PersistentStringTable"
        },
            {
            id: "Load", type: "Method", name: "Load", info: "Class PersistentStringTable", href: "Properties.cls.html#Load"
            },
            {
            id: "Save", type: "Method", name: "Save", info: "Class PersistentStringTable", href: "Properties.cls.html#Save"
            },
        {
        id: "Unicode.Property", type: "Class", name: "Unicode.Property", info: "Properties.cls", href: "Properties.cls.html#Unicode.Property"
        },
            {
            id: "%5B%5D", type: "Method", name: "[]", info: "Class Unicode.Property", href: "Properties.cls.html#%5B%5D"
            },
            {
            id: "Activate", type: "Method", name: "Activate", info: "Class Unicode.Property", href: "Properties.cls.html#Activate"
            },
            {
            id: "BinaryFile", type: "Method", name: "BinaryFile", info: "Class Unicode.Property", href: "Properties.cls.html#BinaryFile"
            },
            {
            id: "BinFile.Qualify", type: "Method", name: "BinFile.Qualify", info: "Class Unicode.Property", href: "Properties.cls.html#BinFile.Qualify"
            },
            {
            id: "getPersistent", type: "Method", name: "getPersistent", info: "Class Unicode.Property", href: "Properties.cls.html#getPersistent"
            },
            {
            id: "loadPersistent", type: "Method", name: "loadPersistent", info: "Class Unicode.Property", href: "Properties.cls.html#loadPersistent"
            },
            {
            id: "RegisterFunctions", type: "Method", name: "RegisterFunctions", info: "Class Unicode.Property", href: "Properties.cls.html#RegisterFunctions"
            },
            {
            id: "RegisterProperties", type: "Method", name: "RegisterProperties", info: "Class Unicode.Property", href: "Properties.cls.html#RegisterProperties"
            },
            {
            id: "savePersistent", type: "Method", name: "savePersistent", info: "Class Unicode.Property", href: "Properties.cls.html#savePersistent"
            },
            {
            id: "setPersistent", type: "Method", name: "setPersistent", info: "Class Unicode.Property", href: "Properties.cls.html#setPersistent"
            },
            {
            id: "SyntaxError", type: "Method", name: "SyntaxError", info: "Class Unicode.Property", href: "Properties.cls.html#SyntaxError"
            },
            {
            id: "UCDFile.Qualify", type: "Method", name: "UCDFile.Qualify", info: "Class Unicode.Property", href: "Properties.cls.html#UCDFile.Qualify"
            },
            {
            id: "Variables", type: "Method", name: "Variables", info: "Class Unicode.Property", href: "Properties.cls.html#Variables"
            },
            {
            id: "NameOf", type: "Attribute", name: "NameOf", info: "Class Unicode.Property", href: "Properties.cls.html#NameOf"
            },
];